import { Component } from '@angular/core';

@Component({
  selector: 'app-transaction-list-item',
  standalone: false,
  templateUrl: './transaction-list-item.html',
  styleUrl: './transaction-list-item.css',
})
export class TransactionListItem {

}
