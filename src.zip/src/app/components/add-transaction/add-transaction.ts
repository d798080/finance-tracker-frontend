import { Component } from '@angular/core';

@Component({
  selector: 'app-add-transaction',
  standalone: false,
  templateUrl: './add-transaction.html',
  styleUrl: './add-transaction.css',
})
export class AddTransaction {

}
