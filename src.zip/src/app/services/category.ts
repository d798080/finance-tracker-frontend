import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { Category, CATEGORIES } from '../data/category';

@Injectable({ providedIn: 'root' })
export class CategoryService {
  getAll(): Observable<Category[]> {
    return of(CATEGORIES);
  }
}