import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { Transaction, TRANSACTIONS } from '../data/transaction';

@Injectable({
  providedIn: 'root',
})
export class TransactionService {

  getTransactions(): Observable<Transaction[]> {
    return of(TRANSACTIONS);
  }
}