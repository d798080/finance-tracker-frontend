import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TransactionList } from './components/transaction-list/transaction-list';
import { AddTransaction } from './components/add-transaction/add-transaction';

const routes: Routes = [
  { path: '', component: TransactionList }, //Si l'URL est "/", affichage de TransactionList
  { path: 'add-transaction', component: AddTransaction }, //Si l'URL est "/add-transaction", affichage de AddTransaction
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],   //Pour enregistrer les routes dans Angular
  exports: [RouterModule] //Pour rendre le Router disponible dans toute l'application
})
export class AppRoutingModule { }
